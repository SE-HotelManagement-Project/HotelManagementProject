package com.project.hotelmanagementproject.controller.systemAccessController;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.project.hotelmanagementproject.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}